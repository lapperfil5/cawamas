import { createClient } from '@supabase/supabase-js'
import { Database } from '../types/database'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})

// Función helper para subir archivos
export const uploadPaymentFile = async (file: File, paymentId: string) => {
  const fileExt = file.name.split('.').pop()
  const fileName = `${paymentId}-${Date.now()}.${fileExt}`
  const filePath = `payment-proofs/${fileName}`

  const { data, error } = await supabase.storage
    .from('payment-files')
    .upload(filePath, file)

  if (error) {
    throw error
  }

  return { fileName, filePath: data.path }
}

// Función helper para obtener URL pública de archivo
export const getFileUrl = (filePath: string) => {
  const { data } = supabase.storage
    .from('payment-files')
    .getPublicUrl(filePath)
  
  return data.publicUrl
}