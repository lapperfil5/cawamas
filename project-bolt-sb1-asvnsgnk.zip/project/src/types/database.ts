export interface Database {
  public: {
    Tables: {
      privates: {
        Row: {
          id: string
          name: string
          code: string
          monthly_amount: number
          description: string | null
          total_residents: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          code: string
          monthly_amount: number
          description?: string | null
          total_residents?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          code?: string
          monthly_amount?: number
          description?: string | null
          total_residents?: number
          created_at?: string
          updated_at?: string
        }
      }
      residents: {
        Row: {
          id: string
          email: string
          name: string
          resident_code: string
          address: string
          unit: string
          phone: string | null
          clabe_account: string | null
          monthly_amount: number | null
          due_date: number
          private_id: string
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          email: string
          name: string
          resident_code: string
          address: string
          unit: string
          phone?: string | null
          clabe_account?: string | null
          monthly_amount?: number | null
          due_date?: number
          private_id: string
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string
          resident_code?: string
          address?: string
          unit?: string
          phone?: string | null
          clabe_account?: string | null
          monthly_amount?: number | null
          due_date?: number
          private_id?: string
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      payments: {
        Row: {
          id: string
          ticket_number: string
          qr_code: string
          resident_id: string
          private_id: string
          amount: number
          month: number
          year: number
          bank_code: string
          bank_name: string
          origin_clabe: string
          tracking_code: string | null
          phone: string | null
          notes: string | null
          admin_notes: string | null
          status: 'processing' | 'approved' | 'rejected' | 'deleted'
          submitted_date: string
          processed_date: string | null
          deleted_date: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          ticket_number: string
          qr_code?: string
          resident_id: string
          private_id: string
          amount: number
          month: number
          year: number
          bank_code: string
          bank_name: string
          origin_clabe: string
          tracking_code?: string | null
          phone?: string | null
          notes?: string | null
          admin_notes?: string | null
          status?: 'processing' | 'approved' | 'rejected' | 'deleted'
          submitted_date?: string
          processed_date?: string | null
          deleted_date?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          ticket_number?: string
          qr_code?: string
          resident_id?: string
          private_id?: string
          amount?: number
          month?: number
          year?: number
          bank_code?: string
          bank_name?: string
          origin_clabe?: string
          tracking_code?: string | null
          phone?: string | null
          notes?: string | null
          admin_notes?: string | null
          status?: 'processing' | 'approved' | 'rejected' | 'deleted'
          submitted_date?: string
          processed_date?: string | null
          deleted_date?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      payment_files: {
        Row: {
          id: string
          payment_id: string
          file_name: string
          file_path: string
          file_size: number | null
          mime_type: string | null
          uploaded_at: string
        }
        Insert: {
          id?: string
          payment_id: string
          file_name: string
          file_path: string
          file_size?: number | null
          mime_type?: string | null
          uploaded_at?: string
        }
        Update: {
          id?: string
          payment_id?: string
          file_name?: string
          file_path?: string
          file_size?: number | null
          mime_type?: string | null
          uploaded_at?: string
        }
      }
      notifications: {
        Row: {
          id: string
          title: string
          message: string
          private_id: string | null
          priority: 'low' | 'medium' | 'high'
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          message: string
          private_id?: string | null
          priority?: 'low' | 'medium' | 'high'
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          message?: string
          private_id?: string | null
          priority?: 'low' | 'medium' | 'high'
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_resident_code: {
        Args: {
          private_code: string
        }
        Returns: string
      }
      generate_ticket_number: {
        Args: {
          private_code: string
          payment_year: number
        }
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
}