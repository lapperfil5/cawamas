export interface User {
  id: string;
  name: string;
  email: string;
  type: 'resident' | 'admin';
  address?: string;
  unit?: string;
  monthlyAmount?: number;
  dueDate?: number; // día del mes para pago
  clabeAccount?: string; // CLABE interbancaria del residente
  phone?: string; // Teléfono del residente
  privateId?: string; // ID de la privada a la que pertenece
  residentCode?: string; // Código único del residente (auto-generado)
}

export interface Private {
  id: string;
  name: string;
  code: string; // Código de 2-3 letras para tickets (ej: "PA", "PB")
  monthlyAmount: number; // Cuota mensual por defecto para esta privada
  description?: string;
  totalResidents: number;
}

export interface Bank {
  code: string;
  name: string;
}

export interface Payment {
  id: string;
  ticketNumber: string;
  residentId: string;
  residentName: string;
  residentCode: string;
  privateId: string;
  privateName: string;
  amount: number;
  month: number;
  year: number;
  bankCode: string;
  bankName: string;
  originClabe: string; // CLABE del banco de origen del residente
  trackingCode?: string;
  proofFile?: File | string;
  status: 'processing' | 'approved' | 'rejected' | 'deleted';
  submittedDate: Date;
  processedDate?: Date;
  deletedDate?: Date;
  notes?: string; // Notas del residente
  adminNotes?: string; // Notas del administrador
  phone?: string; // Teléfono de contacto para este pago
  qrCode?: string; // Código QR para validación
}

export interface PaymentFilter {
  residentId?: string;
  privateId?: string;
  month?: number;
  year?: number;
  status?: Payment['status'];
  ticketNumber?: string;
  trackingCode?: string;
  residentCode?: string;
}

export interface Analytics {
  totalPayments: number;
  approvedPayments: number;
  rejectedPayments: number;
  processingPayments: number;
  overduePayments: number;
  deletedPayments: number;
  totalAmount: number;
  monthlyData: Array<{
    month: string;
    payments: number;
    amount: number;
  }>;
  privateData: Array<{
    privateName: string;
    payments: number;
    amount: number;
    overdueCount: number;
  }>;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  privateId?: string; // Si es null, se muestra a todos
  createdDate: Date;
  isActive: boolean;
  priority: 'low' | 'medium' | 'high';
}

export interface BulkPaymentAction {
  ticketNumber?: string;
  trackingCode?: string;
  action: 'approve' | 'reject';
  reason?: string; // Solo para rechazos
}

export interface ResidentImport {
  residentCode: string;
  name: string;
  email: string;
  address: string;
  unit: string;
  phone: string;
  clabeAccount: string;
  privateId: string;
  monthlyAmount?: number;
  dueDate?: number;
}

export interface OverduePayment {
  residentId: string;
  residentName: string;
  residentCode: string;
  privateId: string;
  privateName: string;
  month: number;
  year: number;
  daysOverdue: number;
  amount: number;
  phone?: string;
}