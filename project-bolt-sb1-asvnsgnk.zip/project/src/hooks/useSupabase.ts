import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { Database } from '../types/database'

type Tables = Database['public']['Tables']

// Hook para privadas
export const usePrivates = () => {
  const [privates, setPrivates] = useState<Tables['privates']['Row'][]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchPrivates = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('privates')
        .select('*')
        .order('name')

      if (error) throw error
      setPrivates(data || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPrivates()
  }, [])

  return { privates, loading, error, refetch: fetchPrivates }
}

// Hook para residentes
export const useResidents = () => {
  const [residents, setResidents] = useState<(Tables['residents']['Row'] & { private_name?: string })[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchResidents = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('residents')
        .select(`
          *,
          privates!inner(name)
        `)
        .eq('is_active', true)
        .order('resident_code')

      if (error) throw error
      
      const residentsWithPrivate = data?.map(resident => ({
        ...resident,
        private_name: (resident.privates as any)?.name
      })) || []

      setResidents(residentsWithPrivate)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  const addResident = async (resident: Tables['residents']['Insert']) => {
    try {
      const { error } = await supabase
        .from('residents')
        .insert([resident])

      if (error) throw error
      await fetchResidents()
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Error al agregar residente')
    }
  }

  const updateResident = async (id: string, updates: Tables['residents']['Update']) => {
    try {
      const { error } = await supabase
        .from('residents')
        .update(updates)
        .eq('id', id)

      if (error) throw error
      await fetchResidents()
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Error al actualizar residente')
    }
  }

  useEffect(() => {
    fetchResidents()
  }, [])

  return { residents, loading, error, refetch: fetchResidents, addResident, updateResident }
}

// Hook para pagos
export const usePayments = () => {
  const [payments, setPayments] = useState<(Tables['payments']['Row'] & { 
    resident_name?: string
    resident_code?: string
    private_name?: string
  })[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchPayments = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('payments')
        .select(`
          *,
          residents!inner(name, resident_code),
          privates!inner(name)
        `)
        .order('submitted_date', { ascending: false })

      if (error) throw error
      
      const paymentsWithDetails = data?.map(payment => ({
        ...payment,
        resident_name: (payment.residents as any)?.name,
        resident_code: (payment.residents as any)?.resident_code,
        private_name: (payment.privates as any)?.name
      })) || []

      setPayments(paymentsWithDetails)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  const addPayment = async (payment: Tables['payments']['Insert']) => {
    try {
      const { error } = await supabase
        .from('payments')
        .insert([payment])

      if (error) throw error
      await fetchPayments()
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Error al agregar pago')
    }
  }

  const updatePayment = async (id: string, updates: Tables['payments']['Update']) => {
    try {
      const { error } = await supabase
        .from('payments')
        .update(updates)
        .eq('id', id)

      if (error) throw error
      await fetchPayments()
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Error al actualizar pago')
    }
  }

  useEffect(() => {
    fetchPayments()
  }, [])

  return { payments, loading, error, refetch: fetchPayments, addPayment, updatePayment }
}

// Hook para notificaciones
export const useNotifications = () => {
  const [notifications, setNotifications] = useState<Tables['notifications']['Row'][]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchNotifications = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setNotifications(data || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  const addNotification = async (notification: Tables['notifications']['Insert']) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert([notification])

      if (error) throw error
      await fetchNotifications()
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Error al agregar notificación')
    }
  }

  const updateNotification = async (id: string, updates: Tables['notifications']['Update']) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .update(updates)
        .eq('id', id)

      if (error) throw error
      await fetchNotifications()
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Error al actualizar notificación')
    }
  }

  useEffect(() => {
    fetchNotifications()
  }, [])

  return { notifications, loading, error, refetch: fetchNotifications, addNotification, updateNotification }
}