import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import { Building2, Mail, Lock, AlertCircle, Loader2, UserPlus } from 'lucide-react'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [showRegister, setShowRegister] = useState(false)
  
  // Campos adicionales para registro
  const [registerData, setRegisterData] = useState({
    name: '',
    residentCode: '',
    address: '',
    unit: '',
    phone: '',
    clabeAccount: '',
    monthlyAmount: 2500,
    dueDate: 15,
    privateId: ''
  })
  
  const { signIn, signUp, isAdmin } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      if (showRegister) {
        const { error } = await signUp(email, password, registerData)
        
        if (error) {
          setError(error)
        } else {
          setError('')
          alert('Usuario registrado exitosamente. Puede iniciar sesión.')
          setShowRegister(false)
          // Limpiar formulario
          setEmail('')
          setPassword('')
          setRegisterData({
            name: '',
            residentCode: '',
            address: '',
            unit: '',
            phone: '',
            clabeAccount: '',
            monthlyAmount: 2500,
            dueDate: 15,
            privateId: ''
          })
        }
      } else {
        const { error } = await signIn(email, password)
        
        if (error) {
          setError(error)
        }
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        {/* Logo y título */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-white p-3 rounded-full shadow-lg">
              <Building2 className="h-12 w-12 text-blue-600" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Fraccionamiento Los Álamos</h1>
          <p className="text-blue-100">Sistema de Gestión de Pagos</p>
        </div>

        {/* Formulario */}
        <div className="bg-white rounded-lg shadow-xl p-8">
          <div className="flex mb-6">
            <button
              onClick={() => setShowRegister(false)}
              className={`flex-1 py-2 px-4 text-center rounded-l-md transition-colors ${
                !showRegister 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Iniciar Sesión
            </button>
            <button
              onClick={() => setShowRegister(true)}
              className={`flex-1 py-2 px-4 text-center rounded-r-md transition-colors ${
                showRegister 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Registrarse
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Correo Electrónico
              </label>
              <div className="relative">
                <Mail className="h-5 w-5 text-gray-400 absolute left-3 top-3" />
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="tu@email.com"
                  required
                  disabled={isLoading}
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Contraseña
              </label>
              <div className="relative">
                <Lock className="h-5 w-5 text-gray-400 absolute left-3 top-3" />
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="••••••••"
                  required
                  disabled={isLoading}
                />
              </div>
            </div>

            {/* Campos adicionales para registro */}
            {showRegister && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre Completo
                  </label>
                  <input
                    type="text"
                    value={registerData.name}
                    onChange={(e) => setRegisterData({...registerData, name: e.target.value})}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Dirección
                    </label>
                    <input
                      type="text"
                      value={registerData.address}
                      onChange={(e) => setRegisterData({...registerData, address: e.target.value})}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Unidad
                    </label>
                    <input
                      type="text"
                      value={registerData.unit}
                      onChange={(e) => setRegisterData({...registerData, unit: e.target.value})}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    value={registerData.phone}
                    onChange={(e) => setRegisterData({...registerData, phone: e.target.value})}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    CLABE Interbancaria
                  </label>
                  <input
                    type="text"
                    value={registerData.clabeAccount}
                    onChange={(e) => setRegisterData({...registerData, clabeAccount: e.target.value})}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="18 dígitos"
                    maxLength={18}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cuota Mensual
                    </label>
                    <input
                      type="number"
                      value={registerData.monthlyAmount}
                      onChange={(e) => setRegisterData({...registerData, monthlyAmount: parseFloat(e.target.value)})}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      min="0"
                      step="0.01"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Día de Pago
                    </label>
                    <select
                      value={registerData.dueDate}
                      onChange={(e) => setRegisterData({...registerData, dueDate: parseInt(e.target.value)})}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      {Array.from({length: 28}, (_, i) => (
                        <option key={i + 1} value={i + 1}>
                          Día {i + 1}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}

            {error && (
              <div className="flex items-center space-x-2 text-red-600 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  {showRegister ? 'Registrando...' : 'Iniciando sesión...'}
                </>
              ) : (
                <>
                  {showRegister ? (
                    <>
                      <UserPlus className="h-4 w-4 mr-2" />
                      Registrarse
                    </>
                  ) : (
                    'Iniciar Sesión'
                  )}
                </>
              )}
            </button>
          </form>

          {/* Información de usuarios demo */}
          {!showRegister && (
            <div className="mt-8 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-sm font-medium text-gray-700 mb-2">Usuarios de demostración:</h3>
              <div className="text-xs text-gray-600 space-y-1">
                <p><strong>Administrador:</strong> admin@fraccionamiento.com</p>
                <p><strong>Residente:</strong> juan.perez@email.com</p>
                <p><strong>Contraseña:</strong> 123456</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}