import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { usePayments } from '../../context/PaymentContext';
import { CreditCard, Clock, CheckCircle, XCircle, AlertTriangle, Bell, QrCode } from 'lucide-react';

export default function ResidentDashboard() {
  const { user } = useAuth();
  const { getResidentPayments, getNotificationsForPrivate, privates } = usePayments();
  
  const payments = getResidentPayments(user?.id || '');
  const notifications = getNotificationsForPrivate(user?.privateId);
  const userPrivate = privates.find(p => p.id === user?.privateId);
  
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth() + 1;
  const currentYear = currentDate.getFullYear();
  const dueDate = user?.dueDate || 15;
  
  // Calcular pagos atrasados
  const overduePayments = [];
  for (let i = 0; i < 12; i++) {
    const checkMonth = currentMonth - i;
    const checkYear = checkMonth <= 0 ? currentYear - 1 : currentYear;
    const adjustedMonth = checkMonth <= 0 ? 12 + checkMonth : checkMonth;
    
    const paymentDueDate = new Date(checkYear, adjustedMonth - 1, dueDate);
    if (paymentDueDate >= currentDate) break;
    
    const existingPayment = payments.find(p => 
      p.month === adjustedMonth && 
      p.year === checkYear && 
      p.status === 'approved'
    );
    
    if (!existingPayment) {
      const daysOverdue = Math.floor((currentDate.getTime() - paymentDueDate.getTime()) / (1000 * 60 * 60 * 24));
      overduePayments.push({
        month: adjustedMonth,
        year: checkYear,
        daysOverdue,
        amount: user?.monthlyAmount || userPrivate?.monthlyAmount || 0
      });
    }
  }

  const latestPayment = payments[0];
  const currentMonthPayment = payments.find(p => p.month === currentMonth && p.year === currentYear);
  const isCurrentMonthPaid = currentMonthPayment?.status === 'approved';

  const statusColors = {
    processing: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300',
    approved: 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300',
    rejected: 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300'
  };

  const statusIcons = {
    processing: Clock,
    approved: CheckCircle,
    rejected: XCircle
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Bienvenido, {user?.name}
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          {user?.address} - {user?.unit} | {userPrivate?.name} | Código: {user?.residentCode}
        </p>
      </div>

      {/* Notificaciones */}
      {notifications.length > 0 && (
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <div className="flex items-start">
            <Bell className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
            <div className="ml-3 flex-1">
              <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200">
                Notificaciones
              </h3>
              <div className="mt-2 space-y-2">
                {notifications.slice(0, 3).map(notification => (
                  <div key={notification.id} className="text-sm text-blue-700 dark:text-blue-300">
                    <strong>{notification.title}:</strong> {notification.message}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Estado actual */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <CreditCard className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Cuota Mensual</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                ${(user?.monthlyAmount || userPrivate?.monthlyAmount || 0).toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            {isCurrentMonthPaid ? (
              <CheckCircle className="h-8 w-8 text-green-600" />
            ) : (
              <AlertTriangle className="h-8 w-8 text-yellow-600" />
            )}
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Estado Actual</p>
              <p className="text-lg font-bold text-gray-900 dark:text-white">
                {isCurrentMonthPaid ? 'Al corriente' : 'Pendiente'}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <Clock className="h-8 w-8 text-red-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pagos Atrasados</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {overduePayments.length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Pagos atrasados detallados */}
      {overduePayments.length > 0 && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
          <div className="flex items-center mb-3">
            <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
            <h3 className="ml-2 text-sm font-medium text-red-800 dark:text-red-200">
              Pagos Vencidos
            </h3>
          </div>
          <div className="space-y-2">
            {overduePayments.map((overdue, index) => (
              <div key={index} className="text-sm text-red-700 dark:text-red-300">
                <strong>
                  {new Date(overdue.year, overdue.month - 1).toLocaleDateString('es-ES', { 
                    month: 'long', 
                    year: 'numeric' 
                  })}
                </strong>
                : ${overdue.amount.toLocaleString()} - {overdue.daysOverdue} días de atraso
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Último pago */}
      {latestPayment && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Último Pago Registrado
          </h2>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Ticket: {latestPayment.ticketNumber}
              </p>
              <p className="text-lg font-medium text-gray-900 dark:text-white">
                ${latestPayment.amount.toLocaleString()}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {new Date(latestPayment.submittedDate).toLocaleDateString('es-ES')}
              </p>
              {latestPayment.qrCode && (
                <div className="flex items-center mt-2">
                  <QrCode className="h-4 w-4 text-gray-500 mr-1" />
                  <span className="text-xs text-gray-500 dark:text-gray-400 font-mono">
                    {latestPayment.qrCode}
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center">
              {(() => {
                const Icon = statusIcons[latestPayment.status];
                return (
                  <div className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${statusColors[latestPayment.status]}`}>
                    <Icon className="h-4 w-4 mr-1" />
                    {latestPayment.status === 'processing' && 'Procesando'}
                    {latestPayment.status === 'approved' && 'Aprobado'}
                    {latestPayment.status === 'rejected' && 'Rechazado'}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Recordatorio de fecha de pago */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
        <div className="flex items-center">
          <CreditCard className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200">Recordatorio</h3>
            <p className="text-sm text-blue-700 dark:text-blue-300">
              Su fecha de pago mensual es el día {dueDate} de cada mes. 
              Los pagos se verifican en 24-48 horas, realice su pago con anticipación.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}