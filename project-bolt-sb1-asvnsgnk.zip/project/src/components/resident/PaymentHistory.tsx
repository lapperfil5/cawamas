import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { usePayments } from '../../context/PaymentContext';
import { Clock, CheckCircle, XCircle, Filter, Download, Trash2, QrCode } from 'lucide-react';

export default function PaymentHistory() {
  const { user } = useAuth();
  const { getResidentPayments, deletePayment } = usePayments();
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletingPayment, setDeletingPayment] = useState<string | null>(null);
  
  const payments = getResidentPayments(user?.id || '');
  
  const filteredPayments = payments.filter(payment => {
    if (filterYear && payment.year !== filterYear) return false;
    if (filterStatus !== 'all' && payment.status !== filterStatus) return false;
    return true;
  }).sort((a, b) => new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime());

  const statusColors = {
    processing: 'bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-800',
    approved: 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-800',
    rejected: 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-800'
  };

  const statusIcons = {
    processing: Clock,
    approved: CheckCircle,
    rejected: XCircle
  };

  const statusLabels = {
    processing: 'Procesando',
    approved: 'Aprobado',
    rejected: 'Rechazado'
  };

  const handleDeletePayment = (paymentId: string) => {
    deletePayment(paymentId);
    setShowDeleteModal(false);
    setDeletingPayment(null);
  };

  const generateCSV = () => {
    const headers = ['Ticket', 'Fecha', 'Mes/Año', 'Monto', 'Banco', 'Estado', 'QR'];
    const rows = filteredPayments.map(payment => [
      payment.ticketNumber,
      new Date(payment.submittedDate).toLocaleDateString('es-ES'),
      `${payment.month}/${payment.year}`,
      `$${payment.amount.toLocaleString()}`,
      payment.bankName,
      statusLabels[payment.status],
      payment.qrCode || ''
    ]);

    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `historial-pagos-${user?.residentCode}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Historial de Pagos</h1>
        <p className="text-gray-600 dark:text-gray-300">Consulte todos sus pagos registrados</p>
      </div>

      {/* Filtros */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-500 dark:text-gray-400" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Filtros:</span>
            </div>
            
            <select
              value={filterYear}
              onChange={(e) => setFilterYear(parseInt(e.target.value))}
              className="border border-gray-300 dark:border-gray-600 rounded-md px-3 py-1 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={2024}>2024</option>
              <option value={2023}>2023</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-md px-3 py-1 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todos los estados</option>
              <option value="processing">Procesando</option>
              <option value="approved">Aprobados</option>
              <option value="rejected">Rechazados</option>
            </select>
          </div>

          <button
            onClick={generateCSV}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Exportar CSV</span>
          </button>
        </div>
      </div>

      {/* Lista de pagos */}
      <div className="space-y-4">
        {filteredPayments.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
            <p className="text-gray-500 dark:text-gray-400">No se encontraron pagos con los filtros seleccionados.</p>
          </div>
        ) : (
          filteredPayments.map((payment) => {
            const Icon = statusIcons[payment.status];
            
            return (
              <div key={payment.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Ticket {payment.ticketNumber}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {new Date(payment.submittedDate).toLocaleDateString('es-ES', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                    {payment.qrCode && (
                      <div className="flex items-center mt-1">
                        <QrCode className="h-4 w-4 text-gray-500 mr-1" />
                        <span className="text-xs text-gray-500 dark:text-gray-400 font-mono">
                          {payment.qrCode}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`px-3 py-1 rounded-full text-sm font-medium flex items-center border ${statusColors[payment.status]}`}>
                      <Icon className="h-4 w-4 mr-1" />
                      {statusLabels[payment.status]}
                    </div>
                    {payment.status === 'processing' && (
                      <button
                        onClick={() => {
                          setDeletingPayment(payment.id);
                          setShowDeleteModal(true);
                        }}
                        className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                        title="Eliminar pago"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Período</p>
                    <p className="text-gray-900 dark:text-white">
                      {new Date(payment.year, payment.month - 1).toLocaleDateString('es-ES', {
                        month: 'long',
                        year: 'numeric'
                      })}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Monto</p>
                    <p className="text-xl font-bold text-gray-900 dark:text-white">
                      ${payment.amount.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Banco</p>
                    <p className="text-gray-900 dark:text-white">{payment.bankName}</p>
                  </div>
                </div>

                {payment.trackingCode && (
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Código de Rastreo</p>
                    <p className="text-gray-900 dark:text-white font-mono">{payment.trackingCode}</p>
                  </div>
                )}

                {payment.notes && (
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Notas</p>
                    <p className="text-gray-900 dark:text-white">{payment.notes}</p>
                  </div>
                )}

                {payment.status === 'rejected' && payment.adminNotes && (
                  <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
                    <p className="text-sm font-medium text-red-800 dark:text-red-200">Motivo del Rechazo:</p>
                    <p className="text-sm text-red-700 dark:text-red-300">{payment.adminNotes}</p>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Modal de confirmación de eliminación */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Confirmar Eliminación
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              ¿Está seguro de que desea eliminar este comprobante de pago? 
              Esta acción no se puede deshacer.
            </p>
            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  setDeletingPayment(null);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                Cancelar
              </button>
              <button
                onClick={() => deletingPayment && handleDeletePayment(deletingPayment)}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}