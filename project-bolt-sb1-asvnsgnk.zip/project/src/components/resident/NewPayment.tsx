import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { usePayments, RECEIVING_CLABE } from '../../context/PaymentContext';
import { useNavigate } from 'react-router-dom';
import { banks } from '../../data/banks';
import { Upload, CreditCard, AlertCircle, CheckCircle, Copy, Phone, FileText } from 'lucide-react';

export default function NewPayment() {
  const { user } = useAuth();
  const { addPayment, privates } = usePayments();
  const navigate = useNavigate();
  
  const userPrivate = privates.find(p => p.id === user?.privateId);
  
  const [formData, setFormData] = useState({
    amount: user?.monthlyAmount || userPrivate?.monthlyAmount || 0,
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    bankCode: '',
    originClabe: '',
    trackingCode: '',
    phone: user?.phone || '',
    notes: ''
  });
  
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const selectedBank = banks.find(b => b.code === formData.bankCode);
      
      await addPayment({
        residentId: user?.id || '',
        residentName: user?.name || '',
        residentCode: user?.residentCode || '',
        privateId: user?.privateId || '',
        privateName: userPrivate?.name || '',
        amount: formData.amount,
        month: formData.month,
        year: formData.year,
        bankCode: formData.bankCode,
        bankName: selectedBank?.name || '',
        originClabe: formData.originClabe,
        trackingCode: formData.trackingCode,
        phone: formData.phone,
        notes: formData.notes,
        proofFile: proofFile?.name || '',
        status: 'processing'
      });

      setSuccess(true);
      setTimeout(() => {
        navigate('/resident/history');
      }, 3000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProofFile(file);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(RECEIVING_CLABE);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Error al copiar:', err);
    }
  };

  if (success) {
    return (
      <div className="max-w-md mx-auto mt-12">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
          <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">¡Pago Registrado!</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Su pago ha sido registrado exitosamente y está siendo procesado.
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Redirigiendo al historial de pagos...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Registrar Nuevo Pago</h1>
        <p className="text-gray-600 dark:text-gray-300">Complete la información de su pago mensual</p>
      </div>

      {/* Información importante */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-6">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200">
              Información Importante
            </h3>
            <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
              Los pagos son verificados en un plazo de 24-48 horas. Realice su pago con anticipación.
              Su pago será revisado y validado por el administrador.
            </p>
          </div>
        </div>
      </div>

      {/* CLABE Receptora */}
      <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-green-800 dark:text-green-200">
              CLABE Receptora del Fraccionamiento
            </h3>
            <p className="text-lg font-mono text-green-900 dark:text-green-100 mt-1">
              {RECEIVING_CLABE}
            </p>
          </div>
          <button
            onClick={copyToClipboard}
            className="flex items-center px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
          >
            <Copy className="h-4 w-4 mr-2" />
            {copied ? 'Copiado!' : 'Copiar'}
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información del residente */}
          <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
            <h3 className="font-medium text-gray-900 dark:text-white mb-2">Información del Residente</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300">{user?.name} ({user?.residentCode})</p>
            <p className="text-sm text-gray-600 dark:text-gray-300">{user?.address} - {user?.unit}</p>
            <p className="text-sm text-gray-600 dark:text-gray-300">{userPrivate?.name}</p>
          </div>

          {/* Período de pago */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Mes
              </label>
              <select
                value={formData.month}
                onChange={(e) => setFormData({...formData, month: parseInt(e.target.value)})}
                className="block w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                {Array.from({length: 12}, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {new Date(2024, i).toLocaleDateString('es-ES', { month: 'long' })}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Año
              </label>
              <select
                value={formData.year}
                onChange={(e) => setFormData({...formData, year: parseInt(e.target.value)})}
                className="block w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value={2024}>2024</option>
                <option value={2025}>2025</option>
              </select>
            </div>
          </div>

          {/* Monto */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Monto del Pago
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2 text-gray-500 dark:text-gray-400">$</span>
              <input
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({...formData, amount: parseFloat(e.target.value)})}
                className="block w-full pl-8 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="0"
                step="0.01"
                required
              />
            </div>
          </div>

          {/* Banco de origen */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Banco de Origen
            </label>
            <select
              value={formData.bankCode}
              onChange={(e) => setFormData({...formData, bankCode: e.target.value})}
              className="block w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Seleccione un banco</option>
              {banks.map(bank => (
                <option key={bank.code} value={bank.code}>
                  {bank.name} ({bank.code})
                </option>
              ))}
            </select>
          </div>

          {/* CLABE de origen */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              CLABE Interbancaria de Origen
            </label>
            <input
              type="text"
              value={formData.originClabe}
              onChange={(e) => setFormData({...formData, originClabe: e.target.value})}
              className="block w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="18 dígitos de su cuenta de origen"
              maxLength={18}
              required
            />
          </div>

          {/* Código de rastreo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Código de Rastreo / Referencia
            </label>
            <input
              type="text"
              value={formData.trackingCode}
              onChange={(e) => setFormData({...formData, trackingCode: e.target.value})}
              className="block w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ej: TR-123456789"
              required
            />
          </div>

          {/* Teléfono de contacto */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <Phone className="h-4 w-4 inline mr-1" />
              Teléfono de Contacto
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({...formData, phone: e.target.value})}
              className="block w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="10 dígitos"
              required
            />
          </div>

          {/* Notas */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <FileText className="h-4 w-4 inline mr-1" />
              Notas Adicionales
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              className="block w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={3}
              placeholder="Información adicional sobre el pago..."
            />
          </div>

          {/* Comprobante */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Comprobante de Pago
            </label>
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <div className="space-y-2">
                <label className="cursor-pointer">
                  <span className="text-blue-600 hover:text-blue-500 font-medium">
                    Seleccionar archivo
                  </span>
                  <input
                    type="file"
                    className="hidden"
                    accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"
                    onChange={handleFileChange}
                    required
                  />
                </label>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Formatos soportados: JPG, PNG, PDF, DOC, DOCX
                </p>
                {proofFile && (
                  <p className="text-sm text-green-600 font-medium">
                    Archivo seleccionado: {proofFile.name}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Botones */}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => navigate('/resident')}
              className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isSubmitting ? (
                'Registrando...'
              ) : (
                <>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Registrar Pago
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}