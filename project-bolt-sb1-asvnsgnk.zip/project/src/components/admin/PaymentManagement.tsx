import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentContext';
import { useAuth } from '../../context/AuthContext';
import { mockUsers } from '../../data/mockData';
import { 
  Search, 
  Filter, 
  Download, 
  Check, 
  X, 
  Clock, 
  CheckCircle, 
  XCircle,
  FileText,
  Calendar,
  User,
  CreditCard,
  AlertTriangle
} from 'lucide-react';
import * as XLSX from 'xlsx';

export default function PaymentManagement() {
  const { payments, updatePaymentStatus, getFilteredPayments } = usePayments();
  const [selectedPayments, setSelectedPayments] = useState<string[]>([]);
  const [filters, setFilters] = useState({
    residentId: '',
    month: '',
    year: '',
    status: '',
    ticketNumber: '',
    trackingCode: ''
  });
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectingPayment, setRejectingPayment] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [receivingBankCode, setReceivingBankCode] = useState('40002'); // BANAMEX por defecto

  const residents = mockUsers.filter(u => u.type === 'resident');
  const filteredPayments = getFilteredPayments(filters).sort((a, b) => 
    new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime()
  );

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleSelectPayment = (paymentId: string) => {
    setSelectedPayments(prev => 
      prev.includes(paymentId) 
        ? prev.filter(id => id !== paymentId)
        : [...prev, paymentId]
    );
  };

  const handleSelectAll = () => {
    if (selectedPayments.length === filteredPayments.length) {
      setSelectedPayments([]);
    } else {
      setSelectedPayments(filteredPayments.map(p => p.id));
    }
  };

  const handleApprovePayment = (paymentId: string) => {
    updatePaymentStatus(paymentId, 'approved');
    setSelectedPayments(prev => prev.filter(id => id !== paymentId));
  };

  const handleRejectPayment = (paymentId: string, reason: string) => {
    updatePaymentStatus(paymentId, 'rejected', reason);
    setSelectedPayments(prev => prev.filter(id => id !== paymentId));
    setShowRejectModal(false);
    setRejectingPayment(null);
    setRejectReason('');
  };

  const handleBulkApprove = () => {
    selectedPayments.forEach(id => updatePaymentStatus(id, 'approved'));
    setSelectedPayments([]);
    setShowBulkActions(false);
  };

  const handleBulkReject = () => {
    if (rejectReason.trim()) {
      selectedPayments.forEach(id => updatePaymentStatus(id, 'rejected', rejectReason));
      setSelectedPayments([]);
      setRejectReason('');
      setShowBulkActions(false);
    }
  };

  const exportToExcel = () => {
    const exportData = filteredPayments.map(payment => ({
      'Ticket': payment.ticketNumber,
      'Residente': payment.residentName,
      'Monto': payment.amount,
      'Mes': payment.month,
      'Año': payment.year,
      'Banco': payment.bankName,
      'Código Rastreo': payment.trackingCode || '',
      'Estado': payment.status === 'approved' ? 'Aprobado' : 
               payment.status === 'rejected' ? 'Rechazado' : 'Procesando',
      'Fecha Envío': new Date(payment.submittedDate).toLocaleDateString('es-ES'),
      'Fecha Procesado': payment.processedDate ? 
                        new Date(payment.processedDate).toLocaleDateString('es-ES') : '',
      'Notas': payment.notes || ''
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Pagos');
    XLSX.writeFile(wb, `pagos-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const exportToTxt = () => {
    // Formato: <fecha aaaa-mm-dd>,<clave de rastreo>,<clave institución financiera emisora>,<clave institución financiera receptora>,<cuenta del residente clabe>,<monto>
    const txtContent = filteredPayments.map(payment => {
      const resident = residents.find(r => r.id === payment.residentId);
      const fecha = payment.submittedDate.toISOString().split('T')[0]; // formato YYYY-MM-DD
      const claveRastreo = payment.trackingCode || '';
      const claveEmisor = payment.bankCode;
      const claveReceptor = receivingBankCode;
      const clabeResidente = resident?.clabeAccount || '';
      const monto = payment.amount.toFixed(2);
      
      return `${fecha},${claveRastreo},${claveEmisor},${claveReceptor},${clabeResidente},${monto}`;
    }).join('\n');

    const blob = new Blob([txtContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `consulta-lotes-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const statusColors = {
    processing: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    approved: 'bg-green-100 text-green-800 border-green-200',
    rejected: 'bg-red-100 text-red-800 border-red-200'
  };

  const statusIcons = {
    processing: Clock,
    approved: CheckCircle,
    rejected: XCircle
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Gestión de Pagos</h1>
        <p className="text-gray-600">Administre y valide los pagos de los residentes</p>
      </div>

      {/* Filtros */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Residente</label>
            <select
              value={filters.residentId}
              onChange={(e) => handleFilterChange('residentId', e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              {residents.map(resident => (
                <option key={resident.id} value={resident.id}>{resident.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mes</label>
            <select
              value={filters.month}
              onChange={(e) => handleFilterChange('month', e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              {Array.from({length: 12}, (_, i) => (
                <option key={i + 1} value={i + 1}>
                  {new Date(2024, i).toLocaleDateString('es-ES', { month: 'long' })}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Año</label>
            <select
              value={filters.year}
              onChange={(e) => handleFilterChange('year', e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              <option value="2024">2024</option>
              <option value="2023">2023</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Estado</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              <option value="processing">Procesando</option>
              <option value="approved">Aprobados</option>
              <option value="rejected">Rechazados</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Ticket</label>
            <input
              type="text"
              value={filters.ticketNumber}
              onChange={(e) => handleFilterChange('ticketNumber', e.target.value)}
              placeholder="TK-2024-001"
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Código Rastreo</label>
            <input
              type="text"
              value={filters.trackingCode}
              onChange={(e) => handleFilterChange('trackingCode', e.target.value)}
              placeholder="11FEF28A36F"
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Configuración para exportación TXT */}
        <div className="mt-4 pt-4 border-t">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Banco Receptor (para archivo TXT)
              </label>
              <select
                value={receivingBankCode}
                onChange={(e) => setReceivingBankCode(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="40002">BANAMEX (40002)</option>
                <option value="40072">BANORTE (40072)</option>
                <option value="40014">SANTANDER (40014)</option>
                <option value="40012">BBVA MEXICO (40012)</option>
                <option value="40021">HSBC (40021)</option>
              </select>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mt-4 pt-4 border-t">
          <div className="flex gap-2">
            <button
              onClick={exportToExcel}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
            >
              <Download className="h-4 w-4 mr-2" />
              Excel
            </button>
            <button
              onClick={exportToTxt}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              <FileText className="h-4 w-4 mr-2" />
              TXT (Consulta Lotes)
            </button>
          </div>

          {selectedPayments.length > 0 && (
            <div className="flex gap-2">
              <button
                onClick={handleBulkApprove}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
              >
                <Check className="h-4 w-4 mr-2" />
                Aprobar ({selectedPayments.length})
              </button>
              <button
                onClick={() => setShowBulkActions(true)}
                className="flex items-center px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
              >
                <X className="h-4 w-4 mr-2" />
                Rechazar ({selectedPayments.length})
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Lista de pagos */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">
              Pagos Registrados ({filteredPayments.length})
            </h2>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={selectedPayments.length === filteredPayments.length && filteredPayments.length > 0}
                onChange={handleSelectAll}
                className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <span className="text-sm text-gray-600">Seleccionar todos</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Selección
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pago
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Residente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Detalles
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Estado
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredPayments.map((payment) => {
                const Icon = statusIcons[payment.status];
                const resident = residents.find(r => r.id === payment.residentId);
                return (
                  <tr key={payment.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedPayments.includes(payment.id)}
                        onChange={() => handleSelectPayment(payment.id)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{payment.ticketNumber}</div>
                        <div className="text-sm text-gray-500">
                          {new Date(payment.submittedDate).toLocaleDateString('es-ES')}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{payment.residentName}</div>
                      {resident?.clabeAccount && (
                        <div className="text-xs text-gray-500 font-mono">CLABE: {resident.clabeAccount}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        ${payment.amount.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(payment.year, payment.month - 1).toLocaleDateString('es-ES', {
                          month: 'long',
                          year: 'numeric'
                        })}
                      </div>
                      <div className="text-sm text-gray-500">{payment.bankName}</div>
                      {payment.trackingCode && (
                        <div className="text-xs text-gray-400 font-mono">{payment.trackingCode}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColors[payment.status]}`}>
                        <Icon className="h-3 w-3 mr-1" />
                        {payment.status === 'processing' && 'Procesando'}
                        {payment.status === 'approved' && 'Aprobado'}
                        {payment.status === 'rejected' && 'Rechazado'}
                      </div>
                      {payment.status === 'rejected' && payment.notes && (
                        <div className="text-xs text-red-600 mt-1">{payment.notes}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {payment.status === 'processing' && (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleApprovePayment(payment.id)}
                            className="text-green-600 hover:text-green-900 p-1 rounded hover:bg-green-50"
                          >
                            <Check className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => {
                              setRejectingPayment(payment.id);
                              setShowRejectModal(true);
                            }}
                            className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredPayments.length === 0 && (
          <div className="p-8 text-center">
            <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No se encontraron pagos con los filtros seleccionados.</p>
          </div>
        )}
      </div>

      {/* Modal de rechazo individual */}
      {showRejectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Rechazar Pago</h3>
            <p className="text-gray-600 mb-4">
              Ingrese el motivo del rechazo para el pago:
            </p>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={3}
              placeholder="Ej: Comprobante ilegible, monto incorrecto, etc."
            />
            <div className="flex space-x-3 mt-4">
              <button
                onClick={() => {
                  setShowRejectModal(false);
                  setRejectingPayment(null);
                  setRejectReason('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button
                onClick={() => rejectingPayment && handleRejectPayment(rejectingPayment, rejectReason)}
                disabled={!rejectReason.trim()}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-50"
              >
                Rechazar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de rechazo masivo */}
      {showBulkActions && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Rechazar Pagos Masivamente
            </h3>
            <p className="text-gray-600 mb-4">
              Rechazar {selectedPayments.length} pago(s) seleccionado(s):
            </p>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={3}
              placeholder="Motivo del rechazo para todos los pagos seleccionados"
            />
            <div className="flex space-x-3 mt-4">
              <button
                onClick={() => {
                  setShowBulkActions(false);
                  setRejectReason('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button
                onClick={handleBulkReject}
                disabled={!rejectReason.trim()}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-50"
              >
                Rechazar Todos
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}