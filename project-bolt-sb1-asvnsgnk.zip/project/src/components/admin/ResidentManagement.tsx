import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { mockUsers } from '../../data/mockData';
import { User } from '../../types';
import { 
  Users, 
  Edit3, 
  Save, 
  X, 
  Calendar, 
  DollarSign, 
  Home, 
  Mail,
  CreditCard,
  AlertCircle
} from 'lucide-react';

export default function ResidentManagement() {
  const [residents, setResidents] = useState<User[]>(mockUsers.filter(u => u.type === 'resident'));
  const [editingResident, setEditingResident] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<User>>({});
  const [success, setSuccess] = useState<string | null>(null);

  const handleEdit = (resident: User) => {
    setEditingResident(resident.id);
    setEditForm(resident);
  };

  const handleSave = () => {
    if (editingResident && editForm) {
      setResidents(prev => prev.map(resident => 
        resident.id === editingResident 
          ? { ...resident, ...editForm }
          : resident
      ));
      setEditingResident(null);
      setEditForm({});
      setSuccess('Información del residente actualizada correctamente');
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  const handleCancel = () => {
    setEditingResident(null);
    setEditForm({});
  };

  const handleInputChange = (field: keyof User, value: string | number) => {
    setEditForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Gestión de Residentes</h1>
        <p className="text-gray-600">Administre la información y configuración de pagos de los residentes</p>
      </div>

      {success && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertCircle className="h-5 w-5 text-green-600" />
            <p className="ml-3 text-sm text-green-800">{success}</p>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center">
            <Users className="h-6 w-6 text-blue-600 mr-3" />
            <h2 className="text-lg font-semibold text-gray-900">
              Residentes Registrados ({residents.length})
            </h2>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {residents.map((resident) => (
            <div key={resident.id} className="p-6">
              {editingResident === resident.id ? (
                /* Modo edición */
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nombre Completo
                      </label>
                      <input
                        type="text"
                        value={editForm.name || ''}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Correo Electrónico
                      </label>
                      <input
                        type="email"
                        value={editForm.email || ''}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Dirección
                      </label>
                      <input
                        type="text"
                        value={editForm.address || ''}
                        onChange={(e) => handleInputChange('address', e.target.value)}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Unidad
                      </label>
                      <input
                        type="text"
                        value={editForm.unit || ''}
                        onChange={(e) => handleInputChange('unit', e.target.value)}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        CLABE Interbancaria
                      </label>
                      <input
                        type="text"
                        value={editForm.clabeAccount || ''}
                        onChange={(e) => handleInputChange('clabeAccount', e.target.value)}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="18 dígitos"
                        maxLength={18}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Cuota Mensual ($)
                      </label>
                      <input
                        type="number"
                        value={editForm.monthlyAmount || 0}
                        onChange={(e) => handleInputChange('monthlyAmount', parseFloat(e.target.value))}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        min="0"
                        step="0.01"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Fecha de Vencimiento (Día del mes)
                      </label>
                      <select
                        value={editForm.dueDate || 5}
                        onChange={(e) => handleInputChange('dueDate', parseInt(e.target.value))}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        {Array.from({length: 28}, (_, i) => (
                          <option key={i + 1} value={i + 1}>
                            Día {i + 1}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex space-x-3 pt-4">
                    <button
                      onClick={handleSave}
                      className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Guardar Cambios
                    </button>
                    <button
                      onClick={handleCancel}
                      className="flex items-center px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
                    >
                      <X className="h-4 w-4 mr-2" />
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                /* Modo vista */
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      <div>
                        <div className="flex items-center text-gray-600 mb-1">
                          <Users className="h-4 w-4 mr-2" />
                          <span className="text-sm font-medium">Residente</span>
                        </div>
                        <p className="text-lg font-semibold text-gray-900">{resident.name}</p>
                        <div className="flex items-center text-gray-500 mt-1">
                          <Mail className="h-4 w-4 mr-1" />
                          <span className="text-sm">{resident.email}</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center text-gray-600 mb-1">
                          <Home className="h-4 w-4 mr-2" />
                          <span className="text-sm font-medium">Ubicación</span>
                        </div>
                        <p className="text-gray-900">{resident.address}</p>
                        <p className="text-sm text-gray-500">{resident.unit}</p>
                        {resident.clabeAccount && (
                          <p className="text-xs text-gray-400 font-mono mt-1">
                            CLABE: {resident.clabeAccount}
                          </p>
                        )}
                      </div>

                      <div>
                        <div className="flex items-center text-gray-600 mb-1">
                          <DollarSign className="h-4 w-4 mr-2" />
                          <span className="text-sm font-medium">Cuota Mensual</span>
                        </div>
                        <p className="text-xl font-bold text-green-600">
                          ${resident.monthlyAmount?.toLocaleString()}
                        </p>
                      </div>

                      <div>
                        <div className="flex items-center text-gray-600 mb-1">
                          <Calendar className="h-4 w-4 mr-2" />
                          <span className="text-sm font-medium">Fecha de Pago</span>
                        </div>
                        <p className="text-gray-900">Día {resident.dueDate} de cada mes</p>
                      </div>
                    </div>
                  </div>

                  <div className="ml-6">
                    <button
                      onClick={() => handleEdit(resident)}
                      className="flex items-center px-4 py-2 border border-blue-600 text-blue-600 rounded-md hover:bg-blue-50 transition-colors"
                    >
                      <Edit3 className="h-4 w-4 mr-2" />
                      Editar
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Información adicional */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <div className="flex items-start">
          <CreditCard className="h-5 w-5 text-blue-600 mt-0.5" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">Configuración de Pagos</h3>
            <p className="text-sm text-blue-700 mt-1">
              Los cambios en la cuota mensual, fecha de vencimiento y CLABE interbancaria se aplicarán a partir del próximo período de facturación. 
              Los residentes serán notificados automáticamente de cualquier cambio en su configuración de pagos.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}