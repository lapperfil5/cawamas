import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentContext';
import { 
  Search, 
  Filter, 
  Download, 
  Trash2,
  Calendar,
  User,
  CreditCard,
  AlertTriangle
} from 'lucide-react';
import * as XLSX from 'xlsx';

export default function DeletedPayments() {
  const { getFilteredPayments } = usePayments();
  const [filters, setFilters] = useState({
    residentId: '',
    month: '',
    year: '',
    ticketNumber: '',
    trackingCode: ''
  });

  const deletedPayments = getFilteredPayments({ ...filters, status: 'deleted' }).sort((a, b) => 
    new Date(b.deletedDate || b.submittedDate).getTime() - new Date(a.deletedDate || a.submittedDate).getTime()
  );

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const exportToExcel = () => {
    const exportData = deletedPayments.map(payment => ({
      'Ticket': payment.ticketNumber,
      'Residente': payment.residentName,
      'Código Residente': payment.residentCode,
      'Privada': payment.privateName,
      'Monto': payment.amount,
      'Mes': payment.month,
      'Año': payment.year,
      'Banco': payment.bankName,
      'Código Rastreo': payment.trackingCode || '',
      'Fecha Envío': new Date(payment.submittedDate).toLocaleDateString('es-ES'),
      'Fecha Eliminación': payment.deletedDate ? 
                          new Date(payment.deletedDate).toLocaleDateString('es-ES') : '',
      'Notas Residente': payment.notes || '',
      'Teléfono': payment.phone || ''
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Pagos Eliminados');
    XLSX.writeFile(wb, `pagos-eliminados-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Pagos Eliminados</h1>
        <p className="text-gray-600 dark:text-gray-300">Historial de comprobantes eliminados por los residentes</p>
      </div>

      {/* Filtros */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Mes</label>
            <select
              value={filters.month}
              onChange={(e) => handleFilterChange('month', e.target.value)}
              className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              {Array.from({length: 12}, (_, i) => (
                <option key={i + 1} value={i + 1}>
                  {new Date(2024, i).toLocaleDateString('es-ES', { month: 'long' })}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Año</label>
            <select
              value={filters.year}
              onChange={(e) => handleFilterChange('year', e.target.value)}
              className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              <option value="2024">2024</option>
              <option value="2023">2023</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Ticket</label>
            <input
              type="text"
              value={filters.ticketNumber}
              onChange={(e) => handleFilterChange('ticketNumber', e.target.value)}
              placeholder="PA-2024-001"
              className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Código Rastreo</label>
            <input
              type="text"
              value={filters.trackingCode}
              onChange={(e) => handleFilterChange('trackingCode', e.target.value)}
              placeholder="11FEF28A36F"
              className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={exportToExcel}
              className="w-full flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
            >
              <Download className="h-4 w-4 mr-2" />
              Excel
            </button>
          </div>
        </div>
      </div>

      {/* Lista de pagos eliminados */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Comprobantes Eliminados ({deletedPayments.length})
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Pago
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Residente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Detalles
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Fechas
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Contacto
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {deletedPayments.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {payment.ticketNumber}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        QR: {payment.qrCode}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {payment.residentName}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {payment.residentCode} - {payment.privateName}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 dark:text-white">
                      ${payment.amount.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {new Date(payment.year, payment.month - 1).toLocaleDateString('es-ES', {
                        month: 'long',
                        year: 'numeric'
                      })}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{payment.bankName}</div>
                    {payment.trackingCode && (
                      <div className="text-xs text-gray-400 dark:text-gray-500 font-mono">
                        {payment.trackingCode}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 dark:text-white">
                      <strong>Enviado:</strong><br />
                      {new Date(payment.submittedDate).toLocaleDateString('es-ES')}
                    </div>
                    {payment.deletedDate && (
                      <div className="text-sm text-red-600 dark:text-red-400 mt-1">
                        <strong>Eliminado:</strong><br />
                        {new Date(payment.deletedDate).toLocaleDateString('es-ES')}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {payment.phone && (
                      <div className="text-sm text-gray-900 dark:text-white">
                        {payment.phone}
                      </div>
                    )}
                    {payment.notes && (
                      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {payment.notes}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {deletedPayments.length === 0 && (
          <div className="p-8 text-center">
            <Trash2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400">
              No se encontraron pagos eliminados con los filtros seleccionados.
            </p>
          </div>
        )}
      </div>

      {/* Información adicional */}
      <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-6">
        <div className="flex items-start">
          <AlertTriangle className="h-5 w-5 text-orange-600 dark:text-orange-400 mt-0.5" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-orange-800 dark:text-orange-200">
              Información sobre Pagos Eliminados
            </h3>
            <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
              Los residentes pueden eliminar sus comprobantes de pago solo cuando están en estado "Procesando". 
              Una vez eliminados, estos registros se mantienen aquí para auditoría y seguimiento administrativo.
              Los pagos eliminados no afectan las estadísticas principales del sistema.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}