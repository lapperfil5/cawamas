import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentContext';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  CreditCard, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle,
  TrendingUp,
  Users,
  DollarSign,
  Filter
} from 'lucide-react';

export default function AdminDashboard() {
  const { getAnalytics, privates } = usePayments();
  const [analyticsFilter, setAnalyticsFilter] = useState({
    privateId: '',
    month: '',
    year: '',
    residentId: ''
  });

  const analytics = getAnalytics(analyticsFilter);

  const statusData = [
    { name: 'Aprobados', value: analytics.approvedPayments, color: '#10b981' },
    { name: 'Procesando', value: analytics.processingPayments, color: '#f59e0b' },
    { name: 'Rechazados', value: analytics.rejectedPayments, color: '#ef4444' },
    { name: 'Atrasados', value: analytics.overduePayments, color: '#f97316' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard Administrativo</h1>
        <p className="text-gray-600 dark:text-gray-300">Resumen general de pagos y actividad</p>
      </div>

      {/* Filtros para estadísticas */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
        <div className="flex items-center mb-3">
          <Filter className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-2" />
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Filtros de Estadísticas</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <select
            value={analyticsFilter.privateId}
            onChange={(e) => setAnalyticsFilter({...analyticsFilter, privateId: e.target.value})}
            className="border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="">Todas las privadas</option>
            {privates.map(priv => (
              <option key={priv.id} value={priv.id}>{priv.name}</option>
            ))}
          </select>

          <select
            value={analyticsFilter.month}
            onChange={(e) => setAnalyticsFilter({...analyticsFilter, month: e.target.value})}
            className="border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="">Todos los meses</option>
            {Array.from({length: 12}, (_, i) => (
              <option key={i + 1} value={i + 1}>
                {new Date(2024, i).toLocaleDateString('es-ES', { month: 'long' })}
              </option>
            ))}
          </select>

          <select
            value={analyticsFilter.year}
            onChange={(e) => setAnalyticsFilter({...analyticsFilter, year: e.target.value})}
            className="border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="">Todos los años</option>
            <option value="2024">2024</option>
            <option value="2023">2023</option>
          </select>

          <button
            onClick={() => setAnalyticsFilter({ privateId: '', month: '', year: '', residentId: '' })}
            className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors"
          >
            Limpiar Filtros
          </button>
        </div>
      </div>

      {/* Métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <CreditCard className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Pagos</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{analytics.totalPayments}</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Aprobados</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{analytics.approvedPayments}</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <Clock className="h-8 w-8 text-yellow-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Procesando</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{analytics.processingPayments}</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <AlertTriangle className="h-8 w-8 text-red-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Atrasados</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{analytics.overduePayments}</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <XCircle className="h-8 w-8 text-gray-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Eliminados</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{analytics.deletedPayments}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Métricas financieras */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-lg text-white">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8" />
            <div className="ml-4">
              <p className="text-green-100">Ingresos Totales</p>
              <p className="text-2xl font-bold">${analytics.totalAmount.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-lg text-white">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8" />
            <div className="ml-4">
              <p className="text-blue-100">Promedio por Pago</p>
              <p className="text-2xl font-bold">
                ${analytics.totalPayments > 0 
                  ? Math.round(analytics.totalAmount / analytics.approvedPayments).toLocaleString()
                  : 0}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-6 rounded-lg text-white">
          <div className="flex items-center">
            <Users className="h-8 w-8" />
            <div className="ml-4">
              <p className="text-purple-100">Tasa Aprobación</p>
              <p className="text-2xl font-bold">
                {analytics.totalPayments > 0 
                  ? Math.round((analytics.approvedPayments / analytics.totalPayments) * 100)
                  : 0}%
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Estadísticas por privada */}
      {analytics.privateData.length > 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Estadísticas por Privada</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {analytics.privateData.map((priv, index) => (
              <div key={index} className="border dark:border-gray-700 rounded-lg p-4">
                <h3 className="font-medium text-gray-900 dark:text-white">{priv.privateName}</h3>
                <div className="mt-2 space-y-1">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Pagos: {priv.payments}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Ingresos: ${priv.amount.toLocaleString()}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Atrasados: {priv.overdueCount}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico de barras - Pagos por mes */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Pagos por Mes</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={analytics.monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip 
                formatter={(value, name) => [
                  name === 'payments' ? `${value} pagos` : `$${Number(value).toLocaleString()}`,
                  name === 'payments' ? 'Pagos' : 'Monto'
                ]}
              />
              <Bar dataKey="payments" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Gráfico circular - Estado de pagos */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Estado de Pagos</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} pagos`, 'Cantidad']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Resumen de alertas */}
      {(analytics.processingPayments > 0 || analytics.overduePayments > 0) && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Alertas y Acciones Requeridas</h2>
          <div className="space-y-3">
            {analytics.processingPayments > 0 && (
              <div className="flex items-center p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md">
                <Clock className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                    {analytics.processingPayments} pagos pendientes de validación
                  </p>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300">
                    Revise los pagos en proceso para aprobar o rechazar
                  </p>
                </div>
              </div>
            )}
            
            {analytics.overduePayments > 0 && (
              <div className="flex items-center p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
                <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-red-800 dark:text-red-200">
                    {analytics.overduePayments} pagos atrasados
                  </p>
                  <p className="text-sm text-red-700 dark:text-red-300">
                    Contacte a los residentes con pagos vencidos
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}