import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Building2, 
  CreditCard, 
  Bell, 
  Shield, 
  Save,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

export default function Settings() {
  const [settings, setSettings] = useState({
    // Configuración general
    subdivisionName: 'Fraccionamiento Los Álamos',
    receivingBank: '40002', // BANAMEX
    receivingAccount: '1234567890',
    defaultDueDate: 15,
    defaultMonthlyAmount: 2500,
    lateFeeDays: 5,
    lateFeeAmount: 100,
    
    // Notificaciones
    emailNotifications: true,
    paymentReminders: true,
    reminderDaysBefore: 3,
    overdueNotifications: true,
    
    // Seguridad
    requireProofUpload: true,
    autoApprovePayments: false,
    maxFileSize: 5, // MB
  });

  const [success, setSuccess] = useState<string | null>(null);

  const banks = [
    { code: '40002', name: 'BANAMEX' },
    { code: '40072', name: 'BANORTE' },
    { code: '40014', name: 'SANTANDER' },
    { code: '40012', name: 'BBVA MEXICO' },
    { code: '40021', name: 'HSBC' },
  ];

  const handleInputChange = (field: string, value: string | number | boolean) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    // Aquí se guardarían los settings en el backend
    setSuccess('Configuración guardada correctamente');
    setTimeout(() => setSuccess(null), 3000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Configuración del Sistema</h1>
        <p className="text-gray-600">Administre la configuración general del fraccionamiento</p>
      </div>

      {success && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <p className="ml-3 text-sm text-green-800">{success}</p>
          </div>
        </div>
      )}

      <div className="space-y-6">
        {/* Configuración General */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-6">
            <Building2 className="h-6 w-6 text-blue-600 mr-3" />
            <h2 className="text-lg font-semibold text-gray-900">Información General</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre del Fraccionamiento
              </label>
              <input
                type="text"
                value={settings.subdivisionName}
                onChange={(e) => handleInputChange('subdivisionName', e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Banco Receptor
              </label>
              <select
                value={settings.receivingBank}
                onChange={(e) => handleInputChange('receivingBank', e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {banks.map(bank => (
                  <option key={bank.code} value={bank.code}>
                    {bank.name} ({bank.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cuenta Receptora
              </label>
              <input
                type="text"
                value={settings.receivingAccount}
                onChange={(e) => handleInputChange('receivingAccount', e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Número de cuenta"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha de Vencimiento por Defecto
              </label>
              <select
                value={settings.defaultDueDate}
                onChange={(e) => handleInputChange('defaultDueDate', parseInt(e.target.value))}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {Array.from({length: 28}, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    Día {i + 1}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cuota Mensual por Defecto ($)
              </label>
              <input
                type="number"
                value={settings.defaultMonthlyAmount}
                onChange={(e) => handleInputChange('defaultMonthlyAmount', parseFloat(e.target.value))}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="0"
                step="0.01"
              />
            </div>
          </div>
        </div>

        {/* Configuración de Pagos */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-6">
            <CreditCard className="h-6 w-6 text-green-600 mr-3" />
            <h2 className="text-lg font-semibold text-gray-900">Configuración de Pagos</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Días de Gracia antes de Recargo
              </label>
              <input
                type="number"
                value={settings.lateFeeDays}
                onChange={(e) => handleInputChange('lateFeeDays', parseInt(e.target.value))}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Monto de Recargo por Atraso ($)
              </label>
              <input
                type="number"
                value={settings.lateFeeAmount}
                onChange={(e) => handleInputChange('lateFeeAmount', parseFloat(e.target.value))}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="0"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tamaño Máximo de Archivo (MB)
              </label>
              <input
                type="number"
                value={settings.maxFileSize}
                onChange={(e) => handleInputChange('maxFileSize', parseInt(e.target.value))}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="1"
                max="50"
              />
            </div>
          </div>

          <div className="mt-6 space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="requireProof"
                checked={settings.requireProofUpload}
                onChange={(e) => handleInputChange('requireProofUpload', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="requireProof" className="ml-2 text-sm text-gray-700">
                Requerir comprobante de pago obligatorio
              </label>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="autoApprove"
                checked={settings.autoApprovePayments}
                onChange={(e) => handleInputChange('autoApprovePayments', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="autoApprove" className="ml-2 text-sm text-gray-700">
                Aprobar pagos automáticamente (no recomendado)
              </label>
            </div>
          </div>
        </div>

        {/* Configuración de Notificaciones */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-6">
            <Bell className="h-6 w-6 text-yellow-600 mr-3" />
            <h2 className="text-lg font-semibold text-gray-900">Notificaciones</h2>
          </div>

          <div className="space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="emailNotifications"
                checked={settings.emailNotifications}
                onChange={(e) => handleInputChange('emailNotifications', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="emailNotifications" className="ml-2 text-sm text-gray-700">
                Enviar notificaciones por correo electrónico
              </label>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="paymentReminders"
                checked={settings.paymentReminders}
                onChange={(e) => handleInputChange('paymentReminders', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="paymentReminders" className="ml-2 text-sm text-gray-700">
                Enviar recordatorios de pago
              </label>
            </div>

            {settings.paymentReminders && (
              <div className="ml-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Días antes del vencimiento para recordatorio
                </label>
                <input
                  type="number"
                  value={settings.reminderDaysBefore}
                  onChange={(e) => handleInputChange('reminderDaysBefore', parseInt(e.target.value))}
                  className="w-32 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="1"
                  max="15"
                />
              </div>
            )}

            <div className="flex items-center">
              <input
                type="checkbox"
                id="overdueNotifications"
                checked={settings.overdueNotifications}
                onChange={(e) => handleInputChange('overdueNotifications', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="overdueNotifications" className="ml-2 text-sm text-gray-700">
                Notificar pagos vencidos
              </label>
            </div>
          </div>
        </div>

        {/* Información de Seguridad */}
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
          <div className="flex items-start">
            <Shield className="h-5 w-5 text-orange-600 mt-0.5" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-orange-800">Configuración de Seguridad</h3>
              <p className="text-sm text-orange-700 mt-1">
                Se recomienda mantener la validación manual de pagos para mayor seguridad. 
                La aprobación automática solo debe usarse en casos especiales y con supervisión constante.
              </p>
            </div>
          </div>
        </div>

        {/* Botón Guardar */}
        <div className="flex justify-end">
          <button
            onClick={handleSave}
            className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Save className="h-5 w-5 mr-2" />
            Guardar Configuración
          </button>
        </div>
      </div>
    </div>
  );
}