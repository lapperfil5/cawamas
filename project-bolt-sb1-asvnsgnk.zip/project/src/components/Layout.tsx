import React from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { usePayments } from '../context/PaymentContext';
import { 
  Home, 
  CreditCard, 
  BarChart3, 
  Settings, 
  LogOut, 
  Building2,
  Users,
  FileText,
  Moon,
  Sun,
  Bell,
  Trash2
} from 'lucide-react';

export default function Layout() {
  const { user, logout } = useAuth();
  const { isDarkMode, toggleDarkMode } = usePayments();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const residentNavItems = [
    { icon: Home, label: 'Inicio', path: '/resident' },
    { icon: CreditCard, label: 'Registrar Pago', path: '/resident/new-payment' },
    { icon: FileText, label: 'Historial', path: '/resident/history' }
  ];

  const adminNavItems = [
    { icon: BarChart3, label: 'Dashboard', path: '/admin' },
    { icon: CreditCard, label: 'Pagos', path: '/admin/payments' },
    { icon: Trash2, label: 'Pagos Eliminados', path: '/admin/deleted-payments' },
    { icon: Users, label: 'Residentes', path: '/admin/residents' },
    { icon: Bell, label: 'Notificaciones', path: '/admin/notifications' },
    { icon: Settings, label: 'Configuración', path: '/admin/settings' }
  ];

  const navItems = user?.type === 'admin' ? adminNavItems : residentNavItems;

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex">
        {/* Sidebar */}
        <div className="w-64 bg-white dark:bg-gray-800 shadow-lg">
          <div className="p-6">
            <div className="flex items-center space-x-3">
              <Building2 className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">Fraccionamiento</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">Los Alamos</p>
              </div>
            </div>
          </div>

          <nav className="mt-6">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`w-full flex items-center px-6 py-3 text-left hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors ${
                    isActive 
                      ? 'bg-blue-50 dark:bg-blue-900/20 border-r-2 border-blue-600 text-blue-600 dark:text-blue-400' 
                      : 'text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="absolute bottom-0 w-64 p-6 border-t dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{user?.name}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {user?.type === 'admin' ? 'Administrador' : `Residente ${user?.residentCode}`}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={toggleDarkMode}
                  className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                >
                  {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                </button>
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto">
          <div className="p-8">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
}