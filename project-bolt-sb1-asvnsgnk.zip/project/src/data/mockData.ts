import { User, Payment, Private, Notification } from '../types';

export const mockPrivates: Private[] = [
  {
    id: 'private-1',
    name: 'Privada Álamos',
    code: 'PA',
    monthlyAmount: 2500,
    description: 'Privada principal del fraccionamiento',
    totalResidents: 15
  },
  {
    id: 'private-2',
    name: 'Privada Robles',
    code: 'PR',
    monthlyAmount: 3000,
    description: 'Privada premium con amenidades adicionales',
    totalResidents: 12
  },
  {
    id: 'private-3',
    name: 'Privada Cedros',
    code: 'PC',
    monthlyAmount: 2800,
    description: 'Privada familiar con áreas verdes',
    totalResidents: 18
  }
];

export const mockUsers: User[] = [
  {
    id: 'admin-1',
    name: 'Administrador',
    email: 'admin@fraccionamiento.com',
    type: 'admin'
  },
  {
    id: 'resident-1',
    name: 'Juan Pérez',
    email: 'juan.perez@email.com',
    type: 'resident',
    address: 'Calle Principal 123',
    unit: 'Casa 1',
    monthlyAmount: 2500,
    dueDate: 5,
    clabeAccount: '123456789112345678',
    phone: '5551234567',
    privateId: 'private-1',
    residentCode: 'PA-001'
  },
  {
    id: 'resident-2',
    name: 'María García',
    email: 'maria.garcia@email.com',
    type: 'resident',
    address: 'Avenida Central 456',
    unit: 'Casa 2',
    monthlyAmount: 3000,
    dueDate: 10,
    clabeAccount: '987654321098765432',
    phone: '5559876543',
    privateId: 'private-2',
    residentCode: 'PR-001'
  },
  {
    id: 'resident-3',
    name: 'Carlos López',
    email: 'carlos.lopez@email.com',
    type: 'resident',
    address: 'Privada Norte 789',
    unit: 'Casa 3',
    monthlyAmount: 2800,
    dueDate: 15,
    clabeAccount: '456789123456789012',
    phone: '5555555555',
    privateId: 'private-3',
    residentCode: 'PC-001'
  }
];

export const mockPayments: Payment[] = [
  {
    id: 'payment-1',
    ticketNumber: 'PA-2024-001',
    residentId: 'resident-1',
    residentName: 'Juan Pérez',
    residentCode: 'PA-001',
    privateId: 'private-1',
    privateName: 'Privada Álamos',
    amount: 2500,
    month: 11,
    year: 2024,
    bankCode: '40002',
    bankName: 'BANAMEX',
    originClabe: '123456789112345678',
    status: 'approved',
    submittedDate: new Date('2024-11-03'),
    processedDate: new Date('2024-11-04'),
    trackingCode: '11FEF28A36F',
    phone: '5551234567',
    notes: 'Pago realizado a tiempo',
    qrCode: 'QR-PA-2024-001'
  },
  {
    id: 'payment-2',
    ticketNumber: 'PR-2024-001',
    residentId: 'resident-2',
    residentName: 'María García',
    residentCode: 'PR-001',
    privateId: 'private-2',
    privateName: 'Privada Robles',
    amount: 3000,
    month: 11,
    year: 2024,
    bankCode: '40072',
    bankName: 'BANORTE',
    originClabe: '987654321098765432',
    status: 'processing',
    submittedDate: new Date('2024-11-08'),
    trackingCode: '22ABC45D78E',
    phone: '5559876543',
    notes: 'Transferencia realizada el viernes',
    qrCode: 'QR-PR-2024-001'
  },
  {
    id: 'payment-3',
    ticketNumber: 'PC-2024-001',
    residentId: 'resident-3',
    residentName: 'Carlos López',
    residentCode: 'PC-001',
    privateId: 'private-3',
    privateName: 'Privada Cedros',
    amount: 2800,
    month: 10,
    year: 2024,
    bankCode: '40014',
    bankName: 'SANTANDER',
    originClabe: '456789123456789012',
    status: 'rejected',
    submittedDate: new Date('2024-10-20'),
    processedDate: new Date('2024-10-22'),
    adminNotes: 'Comprobante ilegible',
    trackingCode: '33XYZ89F12G',
    phone: '5555555555',
    notes: 'Comprobante adjunto',
    qrCode: 'QR-PC-2024-001'
  }
];

export const mockNotifications: Notification[] = [
  {
    id: 'notif-1',
    title: 'Mantenimiento Programado',
    message: 'Se realizará mantenimiento a las áreas comunes el próximo sábado de 8:00 AM a 2:00 PM.',
    privateId: 'private-1',
    createdDate: new Date('2024-11-01'),
    isActive: true,
    priority: 'medium'
  },
  {
    id: 'notif-2',
    title: 'Recordatorio de Pago',
    message: 'Recuerden que los pagos deben realizarse con 24-48 horas de anticipación para su verificación.',
    createdDate: new Date('2024-11-05'),
    isActive: true,
    priority: 'high'
  }
];