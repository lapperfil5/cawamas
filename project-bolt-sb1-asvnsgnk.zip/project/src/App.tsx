import React, { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { PaymentProvider } from './context/PaymentContext'
import Layout from './components/Layout'
import Login from './components/Login'
import ResidentDashboard from './components/resident/ResidentDashboard'
import NewPayment from './components/resident/NewPayment'
import PaymentHistory from './components/resident/PaymentHistory'
import AdminDashboard from './components/admin/AdminDashboard'
import PaymentManagement from './components/admin/PaymentManagement'
import DeletedPayments from './components/admin/DeletedPayments'
import ResidentManagement from './components/admin/ResidentManagement'
import NotificationManagement from './components/admin/NotificationManagement'
import Settings from './components/admin/Settings'
import { Loader2 } from 'lucide-react'

function ProtectedRoute({ 
  children, 
  allowedTypes 
}: { 
  children: React.ReactNode
  allowedTypes: ('resident' | 'admin')[] 
}) {
  const { user, userProfile, loading, isAdmin, isResident } = useAuth()
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    )
  }
  
  if (!user) {
    return <Navigate to="/login" replace />
  }
  
  const userType = isAdmin ? 'admin' : 'resident'
  
  if (!allowedTypes.includes(userType)) {
    return <Navigate to={isAdmin ? '/admin' : '/resident'} replace />
  }
  
  return <>{children}</>
}

function AppContent() {
  const { user, userProfile, loading, isAdmin, isResident } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Cargando...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    )
  }

  return (
    <PaymentProvider>
      <Routes>
        <Route path="/login" element={<Navigate to={isAdmin ? '/admin' : '/resident'} replace />} />
        
        {/* Resident Routes */}
        <Route path="/resident" element={
          <ProtectedRoute allowedTypes={['resident']}>
            <Layout />
          </ProtectedRoute>
        }>
          <Route index element={<ResidentDashboard />} />
          <Route path="new-payment" element={<NewPayment />} />
          <Route path="history" element={<PaymentHistory />} />
        </Route>

        {/* Admin Routes */}
        <Route path="/admin" element={
          <ProtectedRoute allowedTypes={['admin']}>
            <Layout />
          </ProtectedRoute>
        }>
          <Route index element={<AdminDashboard />} />
          <Route path="payments" element={<PaymentManagement />} />
          <Route path="deleted-payments" element={<DeletedPayments />} />
          <Route path="residents" element={<ResidentManagement />} />
          <Route path="notifications" element={<NotificationManagement />} />
          <Route path="settings" element={<Settings />} />
        </Route>

        {/* Default redirect */}
        <Route path="/" element={<Navigate to={isAdmin ? '/admin' : '/resident'} replace />} />
        <Route path="*" element={<Navigate to={isAdmin ? '/admin' : '/resident'} replace />} />
      </Routes>
    </PaymentProvider>
  )
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </BrowserRouter>
  )
}

export default App