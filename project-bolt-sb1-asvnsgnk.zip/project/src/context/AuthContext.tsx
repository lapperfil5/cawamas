import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { User, Session } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'

interface AuthContextType {
  user: User | null
  session: Session | null
  userProfile: any | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<{ error?: string }>
  signUp: (email: string, password: string, userData: any) => Promise<{ error?: string }>
  signOut: () => Promise<void>
  isAdmin: boolean
  isResident: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [userProfile, setUserProfile] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)

  const isAdmin = user?.email?.includes('admin') || false
  const isResident = !isAdmin && !!user

  useEffect(() => {
    // Obtener sesión inicial
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      if (session?.user) {
        fetchUserProfile(session.user)
      }
      setLoading(false)
    })

    // Escuchar cambios de autenticación
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session)
        setUser(session?.user ?? null)
        
        if (session?.user) {
          await fetchUserProfile(session.user)
        } else {
          setUserProfile(null)
        }
        setLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const fetchUserProfile = async (user: User) => {
    try {
      if (user.email?.includes('admin')) {
        // Para administradores, no necesitamos perfil adicional
        setUserProfile({
          id: user.id,
          email: user.email,
          name: 'Administrador',
          type: 'admin'
        })
      } else {
        // Para residentes, obtener datos de la tabla residents
        const { data, error } = await supabase
          .from('residents')
          .select(`
            *,
            privates!inner(name, code)
          `)
          .eq('email', user.email)
          .single()

        if (error) {
          console.error('Error fetching resident profile:', error)
          return
        }

        setUserProfile({
          ...data,
          type: 'resident',
          privateName: (data.privates as any)?.name,
          privateCode: (data.privates as any)?.code
        })
      }
    } catch (error) {
      console.error('Error fetching user profile:', error)
    }
  }

  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true)
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password
      })

      if (error) {
        return { error: error.message }
      }

      return {}
    } catch (error) {
      return { error: 'Error inesperado al iniciar sesión' }
    } finally {
      setLoading(false)
    }
  }

  const signUp = async (email: string, password: string, userData: any) => {
    try {
      setLoading(true)
      
      // Registrar usuario en Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password
      })

      if (authError) {
        return { error: authError.message }
      }

      // Si es un residente, crear el perfil en la tabla residents
      if (!email.includes('admin') && authData.user) {
        const { error: profileError } = await supabase
          .from('residents')
          .insert([{
            email: email,
            name: userData.name,
            resident_code: userData.residentCode,
            address: userData.address,
            unit: userData.unit,
            phone: userData.phone,
            clabe_account: userData.clabeAccount,
            monthly_amount: userData.monthlyAmount,
            due_date: userData.dueDate,
            private_id: userData.privateId
          }])

        if (profileError) {
          console.error('Error creating resident profile:', profileError)
          return { error: 'Error al crear el perfil del residente' }
        }
      }

      return {}
    } catch (error) {
      return { error: 'Error inesperado al registrar usuario' }
    } finally {
      setLoading(false)
    }
  }

  const signOut = async () => {
    try {
      setLoading(true)
      await supabase.auth.signOut()
    } catch (error) {
      console.error('Error signing out:', error)
    } finally {
      setLoading(false)
    }
  }

  const value = {
    user,
    session,
    userProfile,
    loading,
    signIn,
    signUp,
    signOut,
    isAdmin,
    isResident
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}