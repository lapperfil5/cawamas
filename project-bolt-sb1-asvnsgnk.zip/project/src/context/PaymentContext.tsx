import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Payment, PaymentFilter, Analytics, Private, Notification, OverduePayment } from '../types';
import { mockPayments, mockPrivates, mockNotifications } from '../data/mockData';

interface PaymentContextType {
  payments: Payment[];
  privates: Private[];
  notifications: Notification[];
  addPayment: (payment: Omit<Payment, 'id' | 'ticketNumber' | 'submittedDate' | 'qrCode'>) => void;
  updatePaymentStatus: (id: string, status: Payment['status'], adminNotes?: string) => void;
  deletePayment: (id: string) => void;
  getFilteredPayments: (filter: PaymentFilter) => Payment[];
  getAnalytics: (filter?: PaymentFilter) => Analytics;
  getResidentPayments: (residentId: string) => Payment[];
  getOverduePayments: () => OverduePayment[];
  addNotification: (notification: Omit<Notification, 'id' | 'createdDate'>) => void;
  updateNotification: (id: string, updates: Partial<Notification>) => void;
  getNotificationsForPrivate: (privateId?: string) => Notification[];
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

// CLABE receptora del fraccionamiento - CAMBIAR AQUÍ
const RECEIVING_CLABE = '123456789112345678';

export function PaymentProvider({ children }: { children: ReactNode }) {
  const [payments, setPayments] = useState<Payment[]>(mockPayments);
  const [privates] = useState<Private[]>(mockPrivates);
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [isDarkMode, setIsDarkMode] = useState(false);

  const generateTicketNumber = (privateId: string): string => {
    const privateData = privates.find(p => p.id === privateId);
    const privateCode = privateData?.code || 'XX';
    const year = new Date().getFullYear();
    const privatePayments = payments.filter(p => p.privateId === privateId);
    const count = privatePayments.length + 1;
    return `${privateCode}-${year}-${count.toString().padStart(3, '0')}`;
  };

  const generateQRCode = (ticketNumber: string): string => {
    return `QR-${ticketNumber}`;
  };

  const addPayment = (paymentData: Omit<Payment, 'id' | 'ticketNumber' | 'submittedDate' | 'qrCode'>) => {
    const ticketNumber = generateTicketNumber(paymentData.privateId);
    const qrCode = generateQRCode(ticketNumber);
    
    const newPayment: Payment = {
      ...paymentData,
      id: `payment-${Date.now()}`,
      ticketNumber,
      qrCode,
      submittedDate: new Date(),
      status: 'processing'
    };
    
    setPayments(prev => [...prev, newPayment]);
  };

  const updatePaymentStatus = (id: string, status: Payment['status'], adminNotes?: string) => {
    setPayments(prev => prev.map(payment => 
      payment.id === id 
        ? { 
            ...payment, 
            status, 
            processedDate: status !== 'processing' ? new Date() : payment.processedDate,
            deletedDate: status === 'deleted' ? new Date() : payment.deletedDate,
            adminNotes: adminNotes || payment.adminNotes
          }
        : payment
    ));
  };

  const deletePayment = (id: string) => {
    updatePaymentStatus(id, 'deleted');
  };

  const getFilteredPayments = (filter: PaymentFilter): Payment[] => {
    return payments.filter(payment => {
      if (filter.residentId && payment.residentId !== filter.residentId) return false;
      if (filter.privateId && payment.privateId !== filter.privateId) return false;
      if (filter.month && payment.month !== filter.month) return false;
      if (filter.year && payment.year !== filter.year) return false;
      if (filter.status && payment.status !== filter.status) return false;
      if (filter.ticketNumber && !payment.ticketNumber.toLowerCase().includes(filter.ticketNumber.toLowerCase())) return false;
      if (filter.trackingCode && !payment.trackingCode?.toLowerCase().includes(filter.trackingCode.toLowerCase())) return false;
      if (filter.residentCode && !payment.residentCode.toLowerCase().includes(filter.residentCode.toLowerCase())) return false;
      return true;
    });
  };

  const getAnalytics = (filter?: PaymentFilter): Analytics => {
    const filteredPayments = filter ? getFilteredPayments(filter) : payments;
    const activePayments = filteredPayments.filter(p => p.status !== 'deleted');
    
    const totalPayments = activePayments.length;
    const approvedPayments = activePayments.filter(p => p.status === 'approved').length;
    const rejectedPayments = activePayments.filter(p => p.status === 'rejected').length;
    const processingPayments = activePayments.filter(p => p.status === 'processing').length;
    const deletedPayments = filteredPayments.filter(p => p.status === 'deleted').length;
    
    const overduePayments = getOverduePayments().length;

    const totalAmount = activePayments
      .filter(p => p.status === 'approved')
      .reduce((sum, p) => sum + p.amount, 0);

    const currentDate = new Date();
    const monthlyData = Array.from({ length: 12 }, (_, i) => {
      const monthPayments = activePayments.filter(p => p.month === i + 1 && p.year === currentDate.getFullYear());
      return {
        month: new Date(2024, i).toLocaleDateString('es-ES', { month: 'short' }),
        payments: monthPayments.length,
        amount: monthPayments.reduce((sum, p) => sum + p.amount, 0)
      };
    });

    const privateData = privates.map(priv => {
      const privPayments = activePayments.filter(p => p.privateId === priv.id);
      const privOverdue = getOverduePayments().filter(o => o.privateId === priv.id);
      return {
        privateName: priv.name,
        payments: privPayments.length,
        amount: privPayments.filter(p => p.status === 'approved').reduce((sum, p) => sum + p.amount, 0),
        overdueCount: privOverdue.length
      };
    });

    return {
      totalPayments,
      approvedPayments,
      rejectedPayments,
      processingPayments,
      overduePayments,
      deletedPayments,
      totalAmount,
      monthlyData,
      privateData
    };
  };

  const getResidentPayments = (residentId: string): Payment[] => {
    return payments.filter(p => p.residentId === residentId && p.status !== 'deleted')
      .sort((a, b) => new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime());
  };

  const getOverduePayments = (): OverduePayment[] => {
    // Esta función calcularía los pagos atrasados basándose en fechas de vencimiento
    // Por simplicidad, retornamos un array vacío por ahora
    return [];
  };

  const addNotification = (notificationData: Omit<Notification, 'id' | 'createdDate'>) => {
    const newNotification: Notification = {
      ...notificationData,
      id: `notif-${Date.now()}`,
      createdDate: new Date()
    };
    setNotifications(prev => [...prev, newNotification]);
  };

  const updateNotification = (id: string, updates: Partial<Notification>) => {
    setNotifications(prev => prev.map(notif => 
      notif.id === id ? { ...notif, ...updates } : notif
    ));
  };

  const getNotificationsForPrivate = (privateId?: string): Notification[] => {
    return notifications.filter(notif => 
      notif.isActive && (notif.privateId === privateId || !notif.privateId)
    ).sort((a, b) => new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime());
  };

  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  const value = {
    payments,
    privates,
    notifications,
    addPayment,
    updatePaymentStatus,
    deletePayment,
    getFilteredPayments,
    getAnalytics,
    getResidentPayments,
    getOverduePayments,
    addNotification,
    updateNotification,
    getNotificationsForPrivate,
    isDarkMode,
    toggleDarkMode
  };

  return (
    <PaymentContext.Provider value={value}>
      <div className={isDarkMode ? 'dark' : ''}>
        {children}
      </div>
    </PaymentContext.Provider>
  );
}

export function usePayments() {
  const context = useContext(PaymentContext);
  if (context === undefined) {
    throw new Error('usePayments must be used within a PaymentProvider');
  }
  return context;
}

export { RECEIVING_CLABE };